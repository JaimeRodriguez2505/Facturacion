"use client"

import React, { createContext, useState, useContext, useEffect } from "react"
import { useAuth } from "./AuthContext"
import { Company, companyService } from "../service/companyService"

interface CompanyContextType {
  companies: Company[]
  selectedCompany: Company | null
  loading: boolean
  error: string | null
  fetchCompanies: () => Promise<void>
  selectCompany: (company: Company) => void
  createCompany: (companyData: FormData) => Promise<Company>
  updateCompany: (ruc: string, companyData: FormData) => Promise<Company>
  deleteCompany: (ruc: string) => Promise<void>
}

const CompanyContext = createContext<CompanyContextType | undefined>(undefined)

export function useCompany() {
  const context = useContext(CompanyContext)
  if (context === undefined) {
    throw new Error("useCompany debe ser usado dentro de un CompanyProvider")
  }
  return context
}

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [companies, setCompanies] = useState<Company[]>([])
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  // Cargar empresas cuando el usuario está autenticado
  useEffect(() => {
    if (user) {
      fetchCompanies()
    }
  }, [user])

  const fetchCompanies = async () => {
    if (!user) return

    try {
      setLoading(true)
      setError(null)
      const fetchedCompanies = await companyService.getCompanies()
      console.log("Empresas obtenidas:", fetchedCompanies)
      setCompanies(fetchedCompanies)

      // Si hay empresas y no hay una seleccionada, seleccionar la primera
      if (fetchedCompanies.length > 0 && !selectedCompany) {
        setSelectedCompany(fetchedCompanies[0])
      }
    } catch (error: any) {
      console.error("Error al obtener empresas:", error)
      setError(error.response?.data?.message || "Error al obtener empresas")
    } finally {
      setLoading(false)
    }
  }

  const selectCompany = (company: Company) => {
    setSelectedCompany(company)
  }

  const createCompany = async (companyData: FormData): Promise<Company> => {
    try {
      setLoading(true)
      setError(null)
      const newCompany = await companyService.createCompany(companyData)
      
      // Actualizar la lista de empresas
      setCompanies(prevCompanies => [...prevCompanies, newCompany])
      
      // Si es la primera empresa, seleccionarla automáticamente
      if (companies.length === 0) {
        setSelectedCompany(newCompany)
      }
      
      return newCompany
    } catch (error: any) {
      console.error("Error al crear empresa:", error)
      setError(error.response?.data?.message || "Error al crear empresa")
      throw error
    } finally {
      setLoading(false)
    }
  }

  const updateCompany = async (ruc: string, companyData: FormData): Promise<Company> => {
    try {
      setLoading(true)
      setError(null)
      const updatedCompany = await companyService.updateCompany(ruc, companyData)
      
      // Actualizar la lista de empresas
      setCompanies(prevCompanies => 
        prevCompanies.map(company => 
          company.ruc === ruc ? updatedCompany : company
        )
      )
      
      // Si la empresa actualizada es la seleccionada, actualizar también selectedCompany
      if (selectedCompany && selectedCompany.ruc === ruc) {
        setSelectedCompany(updatedCompany)
      }
      
      return updatedCompany
    } catch (error: any) {
      console.error(`Error al actualizar empresa con RUC ${ruc}:`, error)
      setError(error.response?.data?.message || "Error al actualizar empresa")
      throw error
    } finally {
      setLoading(false)
    }
  }

  const deleteCompany = async (ruc: string): Promise<void> => {
    try {
      setLoading(true)
      setError(null)
      await companyService.deleteCompany(ruc)
      
      // Eliminar la empresa de la lista
      setCompanies(prevCompanies => 
        prevCompanies.filter(company => company.ruc !== ruc)
      )
      
      // Si la empresa eliminada era la seleccionada, seleccionar otra o ninguna
      if (selectedCompany && selectedCompany.ruc === ruc) {
        setSelectedCompany(companies.length > 0 ? companies[0] : null)
      }
    } catch (error: any) {
      console.error(`Error al eliminar empresa con RUC ${ruc}:`, error)
      setError(error.response?.data?.message || "Error al eliminar empresa")
      throw error
    } finally {
      setLoading(false)
    }
  }

  return (
    <CompanyContext.Provider
      value={{
        companies,
        selectedCompany,
        loading,
        error,
        fetchCompanies,
        selectCompany,
        createCompany,
        updateCompany,
        deleteCompany
      }}
    >
      {children}
    </CompanyContext.Provider>
  )
}
