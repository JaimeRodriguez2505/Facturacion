"use client"

import type React from "react"
import { Box, Grid, Paper, Typography, Divider, Button, Alert } from "@mui/material"
import { Receipt, People, Inventory, AttachMoney, Business, Add } from "@mui/icons-material"
import MainLayout from "../components/layout/MainLayout"
import { useCompany } from "../contexts/CompanyContext"
import { useNavigate } from "react-router-dom"

const Dashboard: React.FC = () => {
  const { companies, selectedCompany, loading } = useCompany()
  const navigate = useNavigate()

  // Si no hay empresas, mostrar un mensaje para crear una
  if (companies.length === 0) {
    return (
      <MainLayout>
        <Box sx={{ flexGrow: 1, p: 3 }}>
          <Paper elevation={3} sx={{ p: 4, textAlign: "center" }}>
            <Business sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
            <Typography variant="h4" gutterBottom>
              Bienvenido al Sistema de Facturación
            </Typography>
            <Typography variant="body1" paragraph>
              Para comenzar a generar facturas, primero debes registrar una empresa.
            </Typography>
            <Button
              variant="contained"
              color="primary"
              size="large"
              startIcon={<Add />}
              onClick={() => navigate("/companies/new")}
              sx={{ mt: 2 }}
            >
              Registrar Empresa
            </Button>
          </Paper>
        </Box>
      </MainLayout>
    )
  }

  // Si hay empresas pero no hay una seleccionada
  if (!selectedCompany) {
    return (
      <MainLayout>
        <Box sx={{ flexGrow: 1, p: 3 }}>
          <Alert severity="info" sx={{ mb: 3 }}>
            Selecciona una empresa para comenzar a trabajar
          </Alert>
          <Grid container spacing={3}>
            {companies.map((company) => (
              <Grid item xs={12} md={4} key={company.ruc}>
                <Paper
                  elevation={3}
                  sx={{
                    p: 3,
                    display: "flex",
                    flexDirection: "column",
                    height: "100%",
                    cursor: "pointer",
                    transition: "transform 0.2s, box-shadow 0.2s",
                    "&:hover": {
                      transform: "translateY(-5px)",
                      boxShadow: 6,
                    },
                  }}
                  onClick={() => navigate(`/companies/${company.ruc}`)}
                >
                  <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                    <Business sx={{ fontSize: 40, color: "primary.main", mr: 2 }} />
                    <Typography variant="h5" component="div">
                      {company.razon_social}
                    </Typography>
                  </Box>
                  <Typography variant="body1" color="text.secondary" gutterBottom>
                    RUC: {company.ruc}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {company.direccion}
                  </Typography>
                  <Box sx={{ mt: "auto", pt: 2 }}>
                    <Button variant="contained" fullWidth>
                      Seleccionar
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>
      </MainLayout>
    )
  }

  // Dashboard normal con empresa seleccionada
  return (
    <MainLayout>
      <Box sx={{ flexGrow: 1, p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Dashboard
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Bienvenido al sistema de facturación. Aquí tienes un resumen de tu actividad.
        </Typography>

        {/* Información de la empresa */}
        <Paper elevation={3} sx={{ p: 3, mb: 4, mt: 1 }}>
          <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
            <Business sx={{ fontSize: 40, color: "primary.main", mr: 2 }} />
            <Typography variant="h5" component="div">
              {selectedCompany.razon_social}
            </Typography>
          </Box>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="body1" color="text.secondary" gutterBottom>
                <strong>RUC:</strong> {selectedCompany.ruc}
              </Typography>
              <Typography variant="body1" color="text.secondary" gutterBottom>
                <strong>Dirección:</strong> {selectedCompany.direccion}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6} sx={{ display: "flex", justifyContent: { xs: "flex-start", md: "flex-end" } }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => navigate(`/companies/${selectedCompany.ruc}`)}
                sx={{ mr: 1 }}
              >
                Ver Detalles
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate("/facturas/nueva")}
                startIcon={<Add />}
              >
                Nueva Factura
              </Button>
            </Grid>
          </Grid>
        </Paper>

        {/* Tarjetas de resumen */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Paper
              elevation={3}
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                height: 140,
                bgcolor: "primary.light",
                color: "primary.contrastText",
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography variant="h6" gutterBottom>
                  Ventas Totales
                </Typography>
                <AttachMoney fontSize="large" />
              </Box>
              <Typography variant="h4" component="div" sx={{ mt: 1 }}>
                S/. 0.00
              </Typography>
              <Typography variant="body2" sx={{ mt: 1 }}>
                Este mes
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Paper
              elevation={3}
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                height: 140,
                bgcolor: "success.light",
                color: "success.contrastText",
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography variant="h6" gutterBottom>
                  Facturas
                </Typography>
                <Receipt fontSize="large" />
              </Box>
              <Typography variant="h4" component="div" sx={{ mt: 1 }}>
                0
              </Typography>
              <Typography variant="body2" sx={{ mt: 1 }}>
                Emitidas
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Paper
              elevation={3}
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                height: 140,
                bgcolor: "warning.light",
                color: "warning.contrastText",
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography variant="h6" gutterBottom>
                  Clientes
                </Typography>
                <People fontSize="large" />
              </Box>
              <Typography variant="h4" component="div" sx={{ mt: 1 }}>
                0
              </Typography>
              <Typography variant="body2" sx={{ mt: 1 }}>
                Registrados
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Paper
              elevation={3}
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                height: 140,
                bgcolor: "info.light",
                color: "info.contrastText",
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography variant="h6" gutterBottom>
                  Productos
                </Typography>
                <Inventory fontSize="large" />
              </Box>
              <Typography variant="h4" component="div" sx={{ mt: 1 }}>
                0
              </Typography>
              <Typography variant="body2" sx={{ mt: 1 }}>
                En catálogo
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        {/* Acciones rápidas */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Acciones Rápidas
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<Receipt />}
                    onClick={() => navigate("/facturas/nueva")}
                    sx={{ py: 1.5 }}
                  >
                    Nueva Factura
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<People />}
                    onClick={() => navigate("/clientes/nuevo")}
                    sx={{ py: 1.5 }}
                  >
                    Nuevo Cliente
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<Inventory />}
                    onClick={() => navigate("/productos/nuevo")}
                    sx={{ py: 1.5 }}
                  >
                    Nuevo Producto
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<Business />}
                    onClick={() => navigate("/companies/new")}
                    sx={{ py: 1.5 }}
                  >
                    Nueva Empresa
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </MainLayout>
  )
}

export default Dashboard