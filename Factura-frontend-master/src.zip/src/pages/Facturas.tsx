"use client"

import type React from "react"
import { useState } from "react"
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Button,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Tooltip,
} from "@mui/material"
import {
  Add as AddIcon,
  Search as SearchIcon,
  Visibility as VisibilityIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileDownload as FileDownloadIcon,
} from "@mui/icons-material"
import MainLayout from "../components/layout/MainLayout"

interface Factura {
  id: string
  cliente: string
  fecha: string
  vencimiento: string
  total: number
  estado: "Pagada" | "Pendiente" | "Vencida"
}

const facturas: Factura[] = [
  {
    id: "F-001",
    cliente: "Empresa A S.A.C.",
    fecha: "15/03/2023",
    vencimiento: "15/04/2023",
    total: 1500.0,
    estado: "Pagada",
  },
  {
    id: "F-002",
    cliente: "Corporación B E.I.R.L.",
    fecha: "20/03/2023",
    vencimiento: "20/04/2023",
    total: 2300.5,
    estado: "Pendiente",
  },
  {
    id: "F-003",
    cliente: "Distribuidora C S.A.",
    fecha: "25/03/2023",
    vencimiento: "25/04/2023",
    total: 980.75,
    estado: "Pagada",
  },
  {
    id: "F-004",
    cliente: "Servicios D S.A.C.",
    fecha: "01/04/2023",
    vencimiento: "01/05/2023",
    total: 3450.0,
    estado: "Pendiente",
  },
  {
    id: "F-005",
    cliente: "Consultora E S.R.L.",
    fecha: "05/04/2023",
    vencimiento: "05/05/2023",
    total: 1200.25,
    estado: "Vencida",
  },
  {
    id: "F-006",
    cliente: "Importaciones F S.A.",
    fecha: "10/04/2023",
    vencimiento: "10/05/2023",
    total: 5600.8,
    estado: "Pagada",
  },
  {
    id: "F-007",
    cliente: "Tecnología G E.I.R.L.",
    fecha: "15/04/2023",
    vencimiento: "15/05/2023",
    total: 890.5,
    estado: "Pendiente",
  },
  {
    id: "F-008",
    cliente: "Constructora H S.A.C.",
    fecha: "20/04/2023",
    vencimiento: "20/05/2023",
    total: 7800.0,
    estado: "Pagada",
  },
  {
    id: "F-009",
    cliente: "Transportes I S.A.",
    fecha: "25/04/2023",
    vencimiento: "25/05/2023",
    total: 1350.75,
    estado: "Vencida",
  },
  {
    id: "F-010",
    cliente: "Alimentos J S.R.L.",
    fecha: "01/05/2023",
    vencimiento: "01/06/2023",
    total: 2450.3,
    estado: "Pendiente",
  },
]

const Facturas: React.FC = () => {
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(5)
  const [searchTerm, setSearchTerm] = useState("")

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(Number.parseInt(event.target.value, 10))
    setPage(0)
  }

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value)
    setPage(0)
  }

  const filteredFacturas = facturas.filter(
    (factura) =>
      factura.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      factura.cliente.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case "Pagada":
        return "success"
      case "Pendiente":
        return "warning"
      case "Vencida":
        return "error"
      default:
        return "default"
    }
  }

  return (
    <MainLayout>
      <Box sx={{ flexGrow: 1 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Typography variant="h4">Facturas</Typography>
          <Button variant="contained" startIcon={<AddIcon />} size="large">
            Nueva Factura
          </Button>
        </Box>

        <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
            <TextField
              label="Buscar factura"
              variant="outlined"
              size="small"
              value={searchTerm}
              onChange={handleSearchChange}
              sx={{ width: 300 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
            <Button variant="outlined" startIcon={<FileDownloadIcon />}>
              Exportar
            </Button>
          </Box>

          <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="tabla de facturas">
              <TableHead>
                <TableRow>
                  <TableCell>Nº Factura</TableCell>
                  <TableCell>Cliente</TableCell>
                  <TableCell>Fecha Emisión</TableCell>
                  <TableCell>Fecha Vencimiento</TableCell>
                  <TableCell align="right">Total</TableCell>
                  <TableCell>Estado</TableCell>
                  <TableCell align="center">Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredFacturas.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((factura) => (
                  <TableRow key={factura.id} hover>
                    <TableCell component="th" scope="row">
                      {factura.id}
                    </TableCell>
                    <TableCell>{factura.cliente}</TableCell>
                    <TableCell>{factura.fecha}</TableCell>
                    <TableCell>{factura.vencimiento}</TableCell>
                    <TableCell align="right">
                      {new Intl.NumberFormat("es-PE", {
                        style: "currency",
                        currency: "PEN",
                      }).format(factura.total)}
                    </TableCell>
                    <TableCell>
                      <Chip label={factura.estado} color={getEstadoColor(factura.estado) as any} size="small" />
                    </TableCell>
                    <TableCell align="center">
                      <Box sx={{ display: "flex", justifyContent: "center" }}>
                        <Tooltip title="Ver detalle">
                          <IconButton size="small" color="info">
                            <VisibilityIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Editar">
                          <IconButton size="small" color="primary">
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Eliminar">
                          <IconButton size="small" color="error">
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredFacturas.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      No se encontraron facturas
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={filteredFacturas.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Filas por página:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
          />
        </Paper>
      </Box>
    </MainLayout>
  )
}

export default Facturas

