"use client"

import type React from "react"
import { useEffect } from "react"
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  CardActions,
  Divider,
  CircularProgress,
  Alert,
} from "@mui/material"
import { Business, Add, Edit, Delete, CheckCircle, Cancel } from "@mui/icons-material"
import { useNavigate } from "react-router-dom"
import { useCompany } from "../../contexts/CompanyContext"
import MainLayout from "../../components/layout/MainLayout"

const CompanyList: React.FC = () => {
  const navigate = useNavigate()
  const { companies, loading, error, fetchCompanies, selectCompany } = useCompany()

  useEffect(() => {
    fetchCompanies()
  }, [])

  const handleSelectCompany = (company: any) => {
    selectCompany(company)
    navigate("/dashboard")
  }

  if (loading) {
    return (
      <MainLayout>
        <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "70vh" }}>
          <CircularProgress />
        </Box>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <Box sx={{ flexGrow: 1, p: { xs: 2, md: 3 } }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Business sx={{ fontSize: 40, color: "primary.main", mr: 2 }} />
            <Typography variant="h4">Mis Empresas</Typography>
          </Box>
          <Button variant="contained" startIcon={<Add />} onClick={() => navigate("/companies/new")}>
            Nueva Empresa
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        {companies.length === 0 ? (
          <Paper elevation={3} sx={{ p: 4, textAlign: "center" }}>
            <Business sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
            <Typography variant="h5" gutterBottom>
              No tienes empresas registradas
            </Typography>
            <Typography variant="body1" paragraph>
              Para comenzar a generar facturas, primero debes registrar una empresa.
            </Typography>
            <Button
              variant="contained"
              color="primary"
              size="large"
              startIcon={<Add />}
              onClick={() => navigate("/companies/new")}
              sx={{ mt: 2 }}
            >
              Registrar Empresa
            </Button>
          </Paper>
        ) : (
          <Grid container spacing={3}>
            {companies.map((company) => (
              <Grid item xs={12} md={6} lg={4} key={company.ruc}>
                <Card elevation={3} sx={{ height: "100%" }}>
                  <CardContent>
                    <Typography variant="h5" component="div" gutterBottom>
                      {company.razon_social}
                    </Typography>
                    <Divider sx={{ my: 1 }} />
                    <Typography variant="body1" color="text.secondary" gutterBottom>
                      <strong>RUC:</strong> {company.ruc}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      <strong>Dirección:</strong> {company.direccion}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      gutterBottom
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      <strong>Modo:</strong>{" "}
                      {company.production ? (
                        <>
                          <CheckCircle color="success" sx={{ ml: 1, mr: 0.5 }} fontSize="small" /> Producción
                        </>
                      ) : (
                        <>
                          <Cancel color="warning" sx={{ ml: 1, mr: 0.5 }} fontSize="small" /> Pruebas
                        </>
                      )}
                    </Typography>
                  </CardContent>
                  <CardActions sx={{ p: 2, pt: 0 }}>
                    <Button size="small" variant="contained" onClick={() => handleSelectCompany(company)} fullWidth>
                      Seleccionar
                    </Button>
                    <Button
                      size="small"
                      variant="outlined"
                      startIcon={<Edit />}
                      onClick={() => navigate(`/companies/${company.ruc}`)}
                    >
                      Editar
                    </Button>
                    <Button size="small" variant="outlined" color="error" startIcon={<Delete />}>
                      Eliminar
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Box>
    </MainLayout>
  )
}

export default CompanyList

